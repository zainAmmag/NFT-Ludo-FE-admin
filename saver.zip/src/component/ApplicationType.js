const IsMerchant=true;
export default IsMerchant;
//export default IsMerchant=false