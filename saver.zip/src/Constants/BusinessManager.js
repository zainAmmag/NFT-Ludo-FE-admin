export const BaseUrl = "http://198.187.28.244:7577/api/v1";
export const BaseUrl1 = "http://198.187.28.244:7577/api/v1/Nft";

export const IMAGE_BASE_URL = "http://198.187.28.244:7577";
export const AuthenticationTokenId = "b1a531fc052c9e7fb2419c6ed8b9ce12";
export const UserDetailId = "asd871nsd91nd91jni23us21d81";



// export const RawUrl = "https://api.doxpad.com/";
// export const BaseUrl = RawUrl + "api/";
// export const BaseUrlGet = "https://api.doxpad.com/";
// export const TradeUrl = "";
// //export const TradeUrl="http://localhost:21217/"
// export const ImageBaseUrl = RawUrl;
// //export const ImageBaseUrl="http://localhost:62897/Images/"
// export const DomainName = "";
// export const WHCCoinUrl = "";
// export const AuthenticationToken =
//   "858100416504-afcr1kb9jsqi6nu8aql2mr34l1ts0e34*98asdlhj(*&987asdlfkj_)(()*98239487234987Dg$g";

// export const DefaultCurrencyTokenId = "858100416504";
// export const UserTypeTokenId = "98239487234987Dg$g";
// export const UserProfileTokenId = "62628978300097";
// export const LogoSmall = require("../Assets/images/output-onlinepngtools.png");

// export const BaseCurrencies = [
//   {
//     Name: "USD",
//     Image: require("../Assets/Icons/Currencies/USD.png"),
//     symbol: "$",
//   },
//   {
//     Name: "EUR",
//     Image: require("../Assets/Icons/Currencies/EUR.png"),
//     symbol: "€",
//   },
//   {
//     Name: "ZAR",
//     Image: require("../Assets/Icons/Currencies/ZAR.png"),
//     symbol: "R",
//   },
//   {
//     Name: "JPY",
//     Image: require("../Assets/Icons/Currencies/JPY.png"),
//     symbol: "¥",
//   },
//   {
//     Name: "AED",
//     Image: require("../Assets/Icons/Currencies/AED.png"),
//     symbol: "د.إ",
//   },
// ];
