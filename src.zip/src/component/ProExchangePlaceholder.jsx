import React, { Component } from 'react'

export default class ProExchangePlaceholder extends Component {
    render() {
        return null
        
    }
}
